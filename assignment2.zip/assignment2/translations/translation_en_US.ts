<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/1/Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Hi, Human! I want to come with you.</source>
            <comment>Text</comment>
            <translation type="unfinished">Hi, Human! I want to come with you.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/1/Say (1)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>You hurt my hand</source>
            <comment>Text</comment>
            <translation type="unfinished">You hurt my hand</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/1/Say (2)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I want to go home</source>
            <comment>Text</comment>
            <translation type="unfinished">I want to go home</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/1/Say (3)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Where is home?</source>
            <comment>Text</comment>
            <translation type="unfinished">Where is home?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>You hurt my hand</source>
            <comment>Text</comment>
            <translation type="obsolete">You hurt my hand</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Hi, Human! I want to come with you.</source>
            <comment>Text</comment>
            <translation type="obsolete">Hi, Human! I want to come with you.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Hey, Human! A little slower, please!</source>
            <comment>Text</comment>
            <translation type="obsolete">Hey, Human! A little slower, please!</translation>
        </message>
        <message>
            <source>Hey, Human! A little slower, please, you are hurting my hand!</source>
            <comment>Text</comment>
            <translation type="obsolete">Hey, Human! A little slower, please, you are hurting my hand!</translation>
        </message>
        <message>
            <source>Easy, you are hurting my hand!</source>
            <comment>Text</comment>
            <translation type="obsolete">Easy, you are hurting my hand!</translation>
        </message>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Easy, you hurt my hand</source>
            <comment>Text</comment>
            <translation type="obsolete">Easy, you hurt my hand</translation>
        </message>
        <message>
            <source>Easy</source>
            <comment>Text</comment>
            <translation type="obsolete">Easy</translation>
        </message>
        <message>
            <source>You hurt my hand</source>
            <comment>Text</comment>
            <translation type="obsolete">You hurt my hand</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <source>Hi, Human! I want to come with you.</source>
            <comment>Text</comment>
            <translation type="obsolete">Hi, Human! I want to come with you.</translation>
        </message>
        <message>
            <source>I want to go home</source>
            <comment>Text</comment>
            <translation type="obsolete">I want to go home</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (3)</name>
        <message>
            <source>Where is home?</source>
            <comment>Text</comment>
            <translation type="obsolete">Where is home?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Timeline/behavior_layer1/keyframe1/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Timeline/behavior_layer1/keyframe1/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Hi, Human! I want to come with you to </source>
            <comment>Text</comment>
            <translation type="obsolete">Hi, Human! I want to come with you to </translation>
        </message>
    </context>
</TS>
